import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Home from './pages/Home.jsx';
import Crash from './pages/Crash.jsx';
export default function App(){return(<BrowserRouter><Routes><Route path='/' element={<Home/>}/><Route path='/crash' element={<Crash/>}/></Routes></BrowserRouter>)};